import { AnimationDriver } from '@tamagui/core';
export declare function createAnimations<A extends Object>(animations: A): AnimationDriver<A>;
//# sourceMappingURL=createAnimations.d.ts.map