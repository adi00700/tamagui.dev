Much of this is taken from framer-motion.
