/// <reference types="react" />
export interface LayoutGroupContextProps {
    id?: string;
    forceRender?: VoidFunction;
}
export declare const LayoutGroupContext: import("react").Context<LayoutGroupContextProps>;
//# sourceMappingURL=LayoutGroupContext.d.ts.map