throw new Error(
  `This package is deprecated and replaced with @tamagui/animations-moti, please change them out`
)
