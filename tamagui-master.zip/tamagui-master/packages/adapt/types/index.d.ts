export * from './Adapt';
//# sourceMappingURL=index.d.ts.map