import './polyfill';
export * from './createAnimations';
//# sourceMappingURL=index.d.ts.map