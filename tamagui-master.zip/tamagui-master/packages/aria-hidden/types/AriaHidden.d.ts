export { hideOthers } from 'aria-hidden';
//# sourceMappingURL=AriaHidden.d.ts.map