export * from './Animate';
//# sourceMappingURL=index.d.ts.map