import { TakeoutLicense } from '../components/TakeoutLicense'

export default () => <TakeoutLicense />
