alter table "public"."discord_invites" drop column "discord_channel_id";


