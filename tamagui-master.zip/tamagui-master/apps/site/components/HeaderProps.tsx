export type HeaderProps = {
  floating?: boolean
  disableNew?: boolean
  showExtra?: boolean
  forceShowAllLinks?: boolean
  minimal?: boolean
  showAuth?: boolean
}
