#!/bin/bash

rm -r ../.next || true
rm -r ../node_modules/.cache || true
