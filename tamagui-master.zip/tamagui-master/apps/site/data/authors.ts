export const authors = {
  nate: {
    name: 'Nate Wienert',
    twitter: 'natebirdman',
    avatar: '',
  },
}
