#!/bin/bash

# ensure it doesnt complain
rm -r ../../starters/next-expo-solito/node_modules/react-native-gesture-handler

npx pod-install
