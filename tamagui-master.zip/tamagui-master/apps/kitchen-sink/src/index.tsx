import { AppRegistry, View } from 'react-native'

import App from './App'

AppRegistry.registerComponent('main', () => Root)

function Root() {
  return (
    <>
      <App />
    </>
  )
}
