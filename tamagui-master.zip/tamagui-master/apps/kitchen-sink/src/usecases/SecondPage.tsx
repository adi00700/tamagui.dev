import { Square } from 'tamagui'

export function SecondPage() {
  return <Square zIndex={100_001} />
}
