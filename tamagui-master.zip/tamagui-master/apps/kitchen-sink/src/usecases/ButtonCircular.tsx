import { Button } from 'tamagui'

export const ButtonCircular = () => <Button id="circular" circular />
