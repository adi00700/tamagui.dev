import { Button } from 'tamagui'

export const ButtonInverse = () => <Button id="inverse" themeInverse />
