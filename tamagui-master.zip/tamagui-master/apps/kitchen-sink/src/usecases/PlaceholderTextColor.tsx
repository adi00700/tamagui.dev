import { Button, Input } from 'tamagui'

export const PlaceholderTextColor = () => (
  <Input placeholder="hello world" placeholderTextColor="$color10" />
)
