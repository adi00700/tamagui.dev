import { Stack } from '@tamagui/core'
import { Heading } from '@tamagui/sandbox-ui'

// for copy/paste easily to site examples

export const Example = (props) => (
  <Stack px="$2" w={550} $gtSm={{ px: '$6' }}>
    {/* <Heading size={props.big ? 'large' : 'small'}>Lorem ipsum dolor.</Heading> */}
  </Stack>
)
