const View = require('react-native/Libraries/Components/View/ViewNativeComponent').default

export default () => <View style={{ backgroundColor: 'red' }} />
