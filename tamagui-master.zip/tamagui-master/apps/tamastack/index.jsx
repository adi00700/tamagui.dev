import { AppRegistry, LogBox } from 'react-native'
import { App } from './src/App'

AppRegistry.registerComponent('main', () => App)

LogBox.install()

