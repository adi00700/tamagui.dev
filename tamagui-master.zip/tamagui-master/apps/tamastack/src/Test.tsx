import { View } from 'react-native'

export const Test = () => (
  <View style={{ width: 100, height: 100, backgroundColor: 'red' }} />
)
